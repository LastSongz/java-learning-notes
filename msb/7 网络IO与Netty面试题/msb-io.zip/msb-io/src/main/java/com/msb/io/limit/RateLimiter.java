package com.msb.io.limit;

import java.lang.annotation.*;

/**
 * 限流注解
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface RateLimiter {

    /**
     * 限流key前缀
     */
    String key() default "rate_limit:";

    /**
     * 限流时间窗口，单位：秒
     */
    int time() default 60;

    /**
     * 时间窗口内允许的最大请求数
     */
    int count() default 100;

    /**
     * 限流类型
     */
    LimitType limitType() default LimitType.IP;
}

