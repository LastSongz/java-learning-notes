package com.msb.io.limit;
/**
 * 限流类型枚举
 */
public enum LimitType {
    /**
     * 默认策略，根据请求IP进行限流
     */
    IP,

    /**
     * 根据用户ID进行限流
     */
    USER,

    /**
     * 根据接口进行全局限流
     */
    GLOBAL
}