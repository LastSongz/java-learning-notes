package com.msb.io.limit;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.ReturnType;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.stereotype.Component;

import java.util.Collections;
import java.util.concurrent.TimeUnit;

/**
 * 基于Redis ZSET的滑动窗口限流器
 */
@Slf4j
@Component
public class SlidingWindowRateLimiter {

    @Autowired
    private RedisTemplate<String, Object> redisTemplate;

    /**
     * 修复Lua脚本，移除参数验证，直接处理
     */
    private String getFixedLuaScript() {
        return
                "local key = KEYS[1]\n" +
                        "local currentTime = tonumber(ARGV[1]) or 0\n" +
                        "local windowTime = tonumber(ARGV[2]) or 60\n" +  // 提供默认值
                        "local maxCount = tonumber(ARGV[3]) or 100\n" +    // 提供默认值
                        "local requestId = ARGV[4]\n" +
                        "\n" +
                        "-- 确保windowTime是正数\n" +
                        "if windowTime <= 0 then\n" +
                        "    windowTime = 60\n" +
                        "end\n" +
                        "\n" +
                        "-- 确保maxCount是正数\n" +
                        "if maxCount <= 0 then\n" +
                        "    maxCount = 100\n" +
                        "end\n" +
                        "\n" +
                        "-- 计算窗口开始时间\n" +
                        "local windowStart = currentTime - (windowTime * 1000)\n" +
                        "if windowStart > 0 then\n" +
                        "    redis.call('ZREMRANGEBYSCORE', key, 0, windowStart)\n" +
                        "end\n" +
                        "\n" +
                        "-- 统计当前窗口内的请求数量\n" +
                        "local currentCount = redis.call('ZCARD', key) or 0\n" +
                        "\n" +
                        "-- 判断是否超过限制\n" +
                        "if currentCount >= maxCount then\n" +
                        "    return 0\n" +
                        "end\n" +
                        "\n" +
                        "-- 添加当前请求记录\n" +
                        "redis.call('ZADD', key, currentTime, requestId)\n" +
                        "\n" +
                        "-- 设置key的过期时间\n" +
                        "redis.call('PEXPIRE', key, (windowTime * 1000) + 60000)\n" +
                        "\n" +
                        "return 1";
    }

    /**
     * 使用eval执行脚本，避免脚本缓存问题
     */
    public boolean isAllowed(String key, int windowTime, int maxCount) {
        try {
            long currentTime = System.currentTimeMillis();
            String requestId = currentTime + "_" + Math.random();

            // 使用eval执行原始脚本，不缓存
            Object result = redisTemplate.execute(
                    new RedisCallback<Object>() {
                        @Override
                        public Object doInRedis(RedisConnection connection) throws DataAccessException {
                            return connection.eval(
                                    getFixedLuaScript().getBytes(),
                                    ReturnType.INTEGER,
                                    1,
                                    key.getBytes(),
                                    String.valueOf(currentTime).getBytes(),
                                    String.valueOf(windowTime).getBytes(),
                                    String.valueOf(maxCount).getBytes(),
                                    requestId.getBytes()
                            );
                        }
                    }
            );

            return result != null && ((Long)result) == 1L;
        } catch (Exception e) {
            log.error("eval执行异常", e);
            return true;
        }
    }
    /**
     * Java实现版本（非lua脚本，非原子操作，仅用于理解原理）
     */
    public boolean isAllowedJava(String key, int windowTime, int maxCount) {
        try {
            ZSetOperations<String, Object> zSetOps = redisTemplate.opsForZSet();
            long currentTime = System.currentTimeMillis();
            long windowStart = currentTime - windowTime * 1000;

            // 1. 移除窗口之前的过期数据
            zSetOps.removeRangeByScore(key, 0, windowStart);

            // 2. 统计当前窗口内的请求数量
            Long currentCount = zSetOps.zCard(key);

            // 3. 判断是否超过限制
            if (currentCount != null && currentCount >= maxCount) {
                log.warn("请求被限流，key: {}, 窗口: {}秒, 限制: {}次, 当前: {}次",
                        key, windowTime, maxCount, currentCount);
                return false;
            }

            // 4. 添加当前请求记录
            String requestId = currentTime + "_" + Math.random();
            zSetOps.add(key, requestId, currentTime);

            // 5. 设置key的过期时间
            redisTemplate.expire(key, windowTime + 60, TimeUnit.SECONDS);

            log.debug("请求通过，key: {}, 当前计数: {}", key,
                    currentCount != null ? currentCount + 1 : 1);
            return true;
        } catch (Exception e) {
            log.error("滑动窗口限流检查异常", e);
            return true;
        }
    }

    /**
     * 获取当前窗口内的请求数量
     */
    public long getCurrentCount(String key, int windowTime) {
        try {
            ZSetOperations<String, Object> zSetOps = redisTemplate.opsForZSet();
            long currentTime = System.currentTimeMillis();
            long windowStart = currentTime - windowTime * 1000;

            // 移除过期数据
            zSetOps.removeRangeByScore(key, 0, windowStart);

            // 统计数量
            Long count = zSetOps.zCard(key);
            return count != null ? count : 0;
        } catch (Exception e) {
            log.error("获取窗口计数异常", e);
            return 0;
        }
    }
}