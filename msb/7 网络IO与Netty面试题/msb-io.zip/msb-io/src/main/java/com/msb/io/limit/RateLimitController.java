package com.msb.io.limit;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
//  /api/test/ip-limit
@RestController
@RequestMapping("/api")
public class RateLimitController {

    /**
     * IP限流示例：每个IP每分钟最多10次请求
     */
    @RateLimiter(key = "api:test:ip:", time = 60, count = 10, limitType = LimitType.IP)
    @GetMapping("/test/ip-limit")
    public String testIpLimit() {
        return "IP限流测试成功，当前时间：" + System.currentTimeMillis();
    }

    /**
     * 用户限流示例：每个用户每30秒最多5次请求
     */
    @RateLimiter(key = "api:test:user:", time = 30, count = 5, limitType = LimitType.USER)
    @GetMapping("/test/user-limit")
    public String testUserLimit() {
        return "用户限流测试成功，当前时间：" + System.currentTimeMillis();
    }

    /**
     * 全局限流示例：接口全局每分钟最多100次请求
     */
    @RateLimiter(key = "api:test:global:", time = 60, count = 100, limitType = LimitType.GLOBAL)
    @GetMapping("/test/global-limit")
    public String testGlobalLimit() {
        return "全局限流测试成功，当前时间：" + System.currentTimeMillis();
    }

    /**
     * 自定义参数限流
     */
    @RateLimiter(key = "api:order:create:", time = 10, count = 3)
    @GetMapping("/order/create")
    public String createOrder() {
        return "订单创建成功，时间：" + System.currentTimeMillis();
    }
}