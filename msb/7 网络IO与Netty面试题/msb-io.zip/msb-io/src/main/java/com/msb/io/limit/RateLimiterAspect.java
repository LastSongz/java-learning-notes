package com.msb.io.limit;


import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;

/**
 * 限流切面
 */
@Slf4j
@Aspect
@Component
public class RateLimiterAspect {

    @Autowired
    private SlidingWindowRateLimiter rateLimiter;

    @Before("@annotation(rateLimiterAnnotation)")
    public void doBefore(JoinPoint point, RateLimiter rateLimiterAnnotation) {
        // 获取注解参数
        String key = rateLimiterAnnotation.key();
        int time = rateLimiterAnnotation.time();
        int count = rateLimiterAnnotation.count();
        LimitType limitType = rateLimiterAnnotation.limitType();

        // 构建完整的限流key
        String combinedKey = buildKey(key, point, limitType);

        // 检查是否允许请求
        boolean allowed = rateLimiter.isAllowed(combinedKey, time, count);

        if (!allowed) {
            log.warn("接口限流触发，key: {}, 限制: {}/{}秒", combinedKey, count, time);
            throw new RuntimeException("请求过于频繁，请稍后再试");
        }
    }

    /**
     * 构建限流key
     */
    private String buildKey(String keyPrefix, JoinPoint point, LimitType limitType) {
        StringBuilder keyBuilder = new StringBuilder(keyPrefix);

        // 添加方法签名
        MethodSignature signature = (MethodSignature) point.getSignature();
        Method method = signature.getMethod();
        String className = method.getDeclaringClass().getName();
        String methodName = method.getName();
        keyBuilder.append(className).append(":").append(methodName);

        // 根据限流类型添加标识
        switch (limitType) {
            case IP:
                keyBuilder.append(":ip:").append(getClientIp());
                break;
            case USER:
                // 实际项目中可以从Token或Session中获取用户ID
                keyBuilder.append(":user:").append(getUserId());
                break;
            case GLOBAL:
                // 全局限流，不添加额外标识
                break;
            default:
                keyBuilder.append(":ip:").append(getClientIp());
        }

        return keyBuilder.toString();
    }

    /**
     * 获取客户端IP
     */
    private String getClientIp() {
        try {
            HttpServletRequest request = ((ServletRequestAttributes)
                    RequestContextHolder.getRequestAttributes()).getRequest();
            String ip = request.getHeader("X-Forwarded-For");
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getHeader("WL-Proxy-Client-IP");
            }
            if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
                ip = request.getRemoteAddr();
            }
            // 多个代理时取第一个IP
            if (ip != null && ip.contains(",")) {
                ip = ip.split(",")[0].trim();
            }
            return ip != null ? ip : "unknown";
        } catch (Exception e) {
            return "unknown";
        }
    }

    /**
     * 获取用户ID
     */
    private String getUserId() {
        // 实际项目中可以从JWT Token或Session中获取
        // 这里返回默认值
        return "anonymous";
    }
}