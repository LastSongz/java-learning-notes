package com.msb.io;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsbIoApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsbIoApplication.class, args);
    }

}
