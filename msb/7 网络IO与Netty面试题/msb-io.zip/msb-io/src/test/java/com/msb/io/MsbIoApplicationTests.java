package com.msb.io;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsbIoApplicationTests {

    @Test
    void contextLoads() {
    }

}
